# 忆声智护 UI / UX 实施与交付

本次直接修改 `F:\yisheng-guardian-main\miniprogram`，使用原生 JavaScript、WXML、WXSS。四张用户参考图用于布局与材质参照，没有把完整参考图作为运行时背景。产品版本沿用 **V0.1.0**。

## 四个页面

| 页面 | 已实现内容 |
| --- | --- |
| 陪伴 | 保留原人物；放大人物空间；雾蓝玻璃弧面与银杏；真实连接状态；问候浮层；三项话题；折叠/展开聊天；思考提示；发送禁用/错误反馈；消息保留；键盘避让与导航隐藏 |
| 观察 | 统一四步进度、独立玻璃插图、勾选体验说明、任务图片、示例选择、确认与完成页；真实服务中继续禁止伪造录音、提交与评估 |
| 记录 | 未登录、加载骨架、失败重试、空列表与实际列表互斥；使用后端时间和状态；可滚动报告玻璃弹层；演示记录明确标记 |
| 我的 | 真实账号身份；按需展开登录框；密码显隐；持久化大字模式；服务器折叠设置；服务分段选择；保存与连接测试状态；版本信息；确认后退出 |

界面缩减了重复说明，保留影响用户判断的演示/未开放标记。没有添加注册、忘记密码、微信授权登录等未实现入口。

## 公共组件与文件

`app.wxss` 提供颜色、字体、材质、按钮、输入、反馈和间距规则；各页只负责本页布局。`custom-tab-bar/` 提供四等分悬浮导航、安全区域、薄荷选中胶囊、颜色过渡和跳转失败保护。

| 组件 | 职责 |
| --- | --- |
| `components/page-header` | 统一标题、副标题、波形与扩展插槽 |
| `components/status-pill` | 连接/任务状态，文字与圆点共同表达 |
| `components/digital-human` | 独立静态人物展示与未来渲染器接口、缺图降级 |
| `components/chat-panel` | 对话、输入、收放、发送、键盘事件；业务请求仍留在页面 |
| `components/step-progress` | 当前、完成、未完成四步进度 |
| `components/setting-row` | 设置图标、标题、说明与右侧操作插槽 |
| `components/empty-state` | 未登录、空数据与错误状态的统一结构 |
| `components/glass-modal` | 可滚动的报告、关于、录音提示与退出确认 |

`utils/ui.js` 统一安全区、导航同步及键盘计算，避免 Android 视口已缩小后再次扣除键盘高度；`utils/records.js` 按后端 `ScreeningTaskStatus` 枚举映射中文标签，保留原始状态。`config/product.js` 集中产品名与版本。`components/environment-notice` 保留给现有集成使用，本轮在各页面用更紧凑的状态文字表达环境。

按钮和玻璃容器采用公共样式，避免仅为一层插槽创建大量包装组件。微信 `style:v2` 图标按钮显式指定尺寸，防止默认按钮宽度挤压输入。

## 设计系统

| 项目 | 实际值/方式 |
| --- | --- |
| 基础色 | 雾蓝 `#DCE6F5`、冰蓝 `#E4EEF9`、薰衣草 `#E5E5F5`、奶油 `#F8F7F4`、蜜桃 `#F4E1DC` |
| 交互 | `#168773` / `#146653`；薄荷 `#83C5B5`、`#DAEFE9` |
| 文字 | 主文字 `#142536`；次文字 `#586779`；状态使用文字而非单靠颜色 |
| 常规字号，393px 宽 | 页面标题约28px、人物名约32px、问候约24px、卡片约20px、正文约16px、主按钮约17px、辅助14px、状态13px、导航12px |
| 大字模式 | 字体变量增加约25%；按钮、文本与卡片随内容增长；窄屏话题换行，必要时允许滚动 |
| 窄屏 | 正文最低16px、大字最低20px；辅助最低14px；按钮至少44px可点区域 |
| 圆角 | 常规玻璃约22–26px，主要浮层约28px；胶囊999px |
| 材质 | 半透明渐变、白色边缘高光、低对比阴影；主要浮层及导航使用支持时的背景模糊 |
| 动效 | 按压120ms、页面220ms、导航240ms、聊天约280–300ms、弹层240ms；支持减少动态效果 |

详细色板与排版变量见 [design/tokens.json](design/tokens.json)。4/8px 体系通过 rpx 与最小触控尺寸共同实现。

## 数字人与素材

人物继续使用 `assets/avatar-companion.png`，原始人物资源来自仓库已有 `backend/src/main/resources/static/avatar-hero-v1.png`。Logo 沿用 `assets/logo.png`。本轮没有替换人物身份或把小忆用作登录用户。

替换人物时保持透明 PNG、居中胸/腰部构图，更新 `digital-human` 的 `src`，并检查 `.human-portrait` 与紧凑构图。当前仍是**静态图片**，不是实时3D、眨眼或口型驱动；没有开放麦克风。Thinking/Input/Responding/Error 状态用于文字提示与未来渲染器的状态传递，不能视为已具备表情动作。

未来可通过 `attachRenderer(adapter)` 接入 `mount(viewport)` / `setState(state)` / `pause()` / `resume()` / `dispose()`。页面隐藏与组件移除会暂停/释放已连接的渲染器。语音识别、合成、口型、动作与真实观察提交仍属后续阶段。

新观察页插图由 imagegen 生成，透明原图保存在 `design/observation-glass-original.png`，运行资源为压缩导出的 `assets/illustrations/observation-glass.png`（640×480）。它仅是装饰插图，不是实际录音波形。原提示词与工具记录见 [design/IMAGEGEN_PROMPT.txt](design/IMAGEGEN_PROMPT.txt)。

弧面、银杏与新增图标提供 SVG 源文件；线性图标采用统一描边与圆角。背景是独立绘制和预模糊的弥散光与曲面，不是整页截图。资源清单及 SHA-256 见 [design/asset-manifest.json](design/asset-manifest.json)。参考图保存在 `design/references/`，不进入小程序运行包。

## 业务和接口

保留原 `/assistant/chat`、`/assistant/status`、`/actuator/health`、`/user/login`、`/api/v1/screenings` 路径和请求协议。保留 UUID、按后端地址隔离的会话、401 清理、环境切换与过期请求防护；密码与模型密钥没有写进小程序。

必要的业务呈现调整只有：

- 记录额外保留真实 `requestedAt`（兼容已有 `createdAt`）用于显示时间；没有生成时间、统计数值、任务图片或健康分数。
- 演示聊天完成后仍显示“演示模式”，不会错误变成服务已连接。
- 报告改用原生组件实现的玻璃弹层；前往登录会展开已有账号表单；退出登录增加确认。
- 服务器与模式仍需点击“保存设置”；大字偏好即时保存，不连带保存未完成的服务器草稿。

`config/deployment.js`、本机服务器地址、`project.private.config.json`、后端 `.env` 以及数据库均保持原样。GitHub 与可分发源码包使用仓库既有的公共部署配置，不发布 F 盘的本机专用配置。

## 验证与证据

- `node scripts/check.cjs`：JavaScript语法、JSON、四条路由、递归组件、导航、WXML结构、事件处理器和本地资源通过；按 `packOptions.ignore` 估算运行代码/素材约 **1.36 MiB**，低于2 MiB。
- `node --test tests/core.test.cjs`：**25/25**。覆盖真实接口契约、登录密码、会话隔离、晚到响应、演示能力边界、键盘算法、导航失败、记录状态、长报告和退出确认等。
- 微信安装包自带 `wcc.exe` / `wcsc.exe`：全部页面、组件、自定义导航的 WXML/WXSS 原生编译通过。
- 微信开发者工具 **2.02.2609250 Stable**、基础库3.18.1、iPhone16模拟器：**11项运行验证、15张真实运行截图、0个捕获的运行异常**。文字输入与发送实际经过小程序 → 本机 Spring Boot → 模型服务返回，连接测试也调用真实后端。观察验证涵盖真实模式拒绝伪录音和演示模式完整四步；观察页主操作另有位于悬浮导航之上和触控尺寸的断言；记录卡片另有原生宽度断言，避免 style:v2 按钮默认尺寸把标题压成竖排。截图见 `design/verification/native-*.png`，报告见 `design/verification/native-glass-verification.json`。可选开发脚本 `scripts/verify-native-ui.cjs` 使用 `miniprogram-automator@0.13.0`，连接已开启的自动化端口；这些工具不进入前端运行依赖。
- 320×667 的 Chromium 源码布局检查：四页与陪伴页大字变体共5种状态无横向溢出、无缺图、无表达式语法错误；它是 **WXML/WXSS 源码派生的辅助布局检查，不是微信真机截图**。文件名 `source-*.png`，报告为 `narrow-layout-report.json`。
- `native-companion-keyboard-layout.png` 是开发者工具中注入300px高度事件的布局测试；未拍摄实体手机软键盘。测试后已恢复原有服务模式和字号设置。

账号登录的正/负结果和记录列表异常以契约测试验证；当前没有提供真实账号，不能声称已验证真实账号登录和带健康报告的真实记录查询。模拟器中真实记录的未登录状态及演示报告弹层已运行验证。

## 运行、兼容与尚未验证

在微信开发者工具导入本目录，直接编译，无需“构建 npm”。首次运行模式取决于 `config/deployment.js` 与已保存偏好；在“我的”切换环境并保存。完整仓库根目录 `start-local.cmd` 启动既有本机后端；密钥继续放后端 `.env`。前端新增第三方运行依赖：**0**。素材导出仅开发时使用 Pillow 与可选 Sharp，SVG 可在常见矢量编辑器继续编辑。图标脚本、弥散背景脚本与矢量导出脚本均在 `scripts/`，无需运行它们即可编译前端。

玻璃效果是 WebView 中可落地的半透明/模糊合成，不包含真实折射与光线追踪。背景已预模糊，普通列表避免每项实时滤镜；不支持 `backdrop-filter` 时保留渐变填充、静态环境色与边缘高光。系统减少动态效果会取消非必要过渡；减少透明度时使用较实的底色。

保留微信原生状态栏、标题栏和胶囊，标题字号与顶部背景受原生导航限制；没有绘制假状态栏。自定义 tabBar 在各原生页面中分别创建，首次切换的连续程度受微信页面加载影响。观察准备页在较短屏或大字模式中需要滚动，底部内容已预留导航与安全区。

**尚未验证**：实体 iPhone/Android 的软键盘、VoiceOver/TalkBack、系统大字体、Android不同内核、低性能设备帧率、真实录音/分析、实时3D、物理手机访问局域网后端。发布到手机仍需按微信要求配置合法HTTPS服务域名；本机开发配置不能视为线上部署完成。

## 打包内容

- 小程序源码压缩包：包含四页代码、组件、图片、设计源文件、参考图与说明；排除本机私有配置、密钥、数据库与依赖缓存。
- [设计与图片素材包](design/yisheng-guardian-design-assets.zip)：运行图片、SVG源文件、原始插图、色板、四张参考图、实际运行截图与验证报告。
- `design/verification/native-pages.png`：四页真实开发者工具截图拼接，记录页为明确标注的演示状态。

GitHub 分支：`feature/ios-ui`。所有功能仍以真实后端和已实现能力为边界。
